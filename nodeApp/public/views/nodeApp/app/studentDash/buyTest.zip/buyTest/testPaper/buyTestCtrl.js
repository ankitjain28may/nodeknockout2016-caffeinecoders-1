'use strict';

angular.module('app.student').controller('studentbuyTestCtrl',
    function($scope, Question, User, TestPaper, Subject, localStorageService, StudentPaper) {
        Subject.getList().then(function(data) {
            $scope.subject = data;
        });
        TestPaper.getList().then(function(data) {
            $scope.testpapers = data;
            console.log(data);
        });
        $scope.userdata = {};
        var studentID = localStorageService.get("id");
        User.one(studentID).get().then(function(data) {
            $scope.userdata = data;
            $scope.userdata.cart = JSON.parse($scope.userdata.cart);
            $scope.itemNum = $scope.userdata.cart.length;
        });
        $scope.add = function(paper) {
            console.log('test');
            if (!paper.isUsed) {
                if (paper.price != '0') {
                    $scope.itemNum += parseInt(1);
                    $scope.userdata.cart.push(paper);
                    console.log($scope.userdata.cart);
                    $scope.userdata.cart = JSON.stringify($scope.userdata.cart);
                    $scope.userdata.save().then(function(resp) {
                        $scope.userdata.cart = JSON.parse($scope.userdata.cart);
                        $.smallBox({
                            title: "Done !",
                            content: "Paper Added To Cart",
                            color: "#739E73",
                            iconSmall: "fa  fa-paper-plane",
                            timeout: 2000
                        });

                    });
                }
                if (paper.price == '0') {
                    testPaperAdd(paper);
                }
            }
            paper.isUsed = true;

        }

        var testPaperAdd = function(paper) {
            var testpaperID = paper.testpaperID;

            StudentPaper.one().get({
                studentID: studentID,
                testpaperID: testpaperID
            }).then(function(resp) {
                $.smallBox({
                    title: "Done !",
                    content: "Demo added to Assessments",
                    color: "#739E73",
                    iconSmall: "fa  fa-paper-plane",
                    timeout: 2000
                });
                var studentpaper = {
                    studentID: studentID,
                    testPaperName: paper.name,
                    testpaperID: paper.testpaperID,
                    subjectID: paper.subjectID,
                    totalQuestions: paper.totalQuestions,
                    totalTime: paper.totalTime,
                    totalMarks: paper.totalMarks
                };
                if (resp.length == 0) {

                    Question.getList({
                            testpaperID: paper.testpaperID
                        }).then(function(data) {
                            studentpaper.testData = JSON.stringify(data);
                            studentpaper.report = 'http://45.55.228.207:52295/reports/' + studentID + '/' + testpaperID + '.pdf';
                            StudentPaper.post(studentpaper).then(function(resp) {
                                console.log(resp);
                            })
                        })
                        //getSubjectID(paper.subjectID);
                }
                // console.log(resp);
            })

        }
        function getTestQuestions() {
            $scope.questions = Question.getList({
                testpaperID: $scope.testpaper.testpaperID
            }).$object;

            $scope.studentPaper.testData = JSON.stringify($scope.questions);

            StudentPaper.post($scope.studentPaper).then(function() {

            })
        }

    })

.factory('SubjectRestangular', function(Restangular) {
    return Restangular.withConfig(function(RestangularConfigurer) {
        RestangularConfigurer.setRestangularFields({
            id: '_id'
        });
    });
})

.factory('Subject', function(SubjectRestangular) {
    return SubjectRestangular.service('subject');
});
